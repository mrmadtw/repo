mv /usr/lib/TweakInject/WatchdogLite.dylib.no /usr/lib/TweakInject/WatchdogLite.dylib
mv /usr/lib/TweakInject/Watchdog.dylib.no /usr/lib/TweakInject/Watchdog.dylib